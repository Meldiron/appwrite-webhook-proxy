module.exports = async (req, res) => {
    res.json({ payload: req.payload })
}
